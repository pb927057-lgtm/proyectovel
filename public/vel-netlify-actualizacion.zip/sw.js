// Service Worker para VEL PWA - Modo Offline-First para activos estáticos exclusivamente
// IMPORTANTE: NO guarda datos personales, mensajes, credenciales ni claves criptográficas.
// Los datos personales residen exclusivamente en el IndexedDB local del navegador.

const CACHE_NAME = 'vel-static-cache-v1';

// Activos esenciales de la interfaz para precargar
const PRECACHE_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icon.svg',
  '/pwa-192x192.png',
  '/pwa-512x512.png',
  '/pwa-maskable-512x512.png',
  '/apple-touch-icon.png'
];

self.addEventListener('install', (event) => {
  // Activa el nuevo service worker inmediatamente
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(PRECACHE_ASSETS).catch((err) => {
        console.warn('Precache de algunos activos no completado:', err);
      });
    })
  );
});

self.addEventListener('activate', (event) => {
  // Limpia cachés antiguos de versiones anteriores
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_NAME)
          .map((name) => caches.delete(name))
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const request = event.request;

  // Solo interceptar peticiones GET
  if (request.method !== 'GET') {
    return;
  }

  const url = new URL(request.url);

  // No interceptar peticiones a orígenes externos ni APIs de backend
  if (url.origin !== self.location.origin) {
    return;
  }

  // Para navegaciones HTML (SPA): Estrategia Network-First con fallback a caché
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (response && response.status === 200) {
            const copy = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
          }
          return response;
        })
        .catch(() => {
          return caches.match('/index.html').then((cached) => cached || caches.match('/'));
        })
    );
    return;
  }

  // Para archivos estáticos (JS, CSS, imágenes, fuentes, JSON): Cache-First con fallback a red
  event.respondWith(
    caches.match(request).then((cachedResponse) => {
      if (cachedResponse) {
        // En segundo plano actualiza el caché (Stale-While-Revalidate)
        fetch(request)
          .then((networkResponse) => {
            if (networkResponse && networkResponse.status === 200) {
              caches.open(CACHE_NAME).then((cache) => cache.put(request, networkResponse));
            }
          })
          .catch(() => {
            // Silencioso si no hay red
          });
        return cachedResponse;
      }

      return fetch(request).then((networkResponse) => {
        if (!networkResponse || networkResponse.status !== 200) {
          return networkResponse;
        }

        // Cachear solo recursos estáticos seguros
        const contentType = networkResponse.headers.get('content-type') || '';
        const isStaticAsset =
          contentType.includes('javascript') ||
          contentType.includes('css') ||
          contentType.includes('image') ||
          contentType.includes('font') ||
          url.pathname.startsWith('/assets/');

        if (isStaticAsset) {
          const responseToCache = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(request, responseToCache));
        }

        return networkResponse;
      });
    })
  );
});
